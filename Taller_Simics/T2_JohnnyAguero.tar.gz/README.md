En el siguiente folder se presenta un PDF con la informacion requerida de la investigacion

Tambien se adjunta el archivo .asm que contiene el algortimo para resolver el ASM: GENERADOR DE NUMEROS PSEUDO-ALEATORIOS.
Para poder ejecutar dicho archivo se tienen que realizar los pasos dados en el documento del Taller#2 para SIMICS, una vez se tenga SIMICS y el entorno del proyecto este configurado se podra ejecutar el archivo.


Instrucciones:
1- Instalar SIMICS https://www.intel.com/content/www/us/en/developer/articles/guide/simics-simulator-installation.html
2- Configurar el entorno y virtualziar de ser necesario.
3- Desde la terminal navegar hasta la direccion del proyecto
4- Ejecutar ./simics
5- Realizar los comandos necesarios para poder visualizar correctamente el archivo .asm
